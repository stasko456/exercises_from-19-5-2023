﻿using System.Diagnostics.CodeAnalysis;

namespace project_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ex 1:
            int[] coins = { 200, 100, 50, 20, 10, 5, 2, 1 };

            Console.WriteLine("Enter a sum as a whole number, not a decimal:");
            int sum = int.Parse(Console.ReadLine());

            int count = CountCoins(sum, coins);
            
            Console.WriteLine($"The count of every coin used to devide the sum is: {count}");
        }

        static int CountCoins(int sum, int[] coins)
        {
            int count = 0;
            foreach (int coin in coins)
            {
                if (sum == 0)
                {
                    break;
                }
                else
                {
                    count = count + sum / coin;
                    sum = sum % coin;
                }
            }

            return count;
        }
    }
}
