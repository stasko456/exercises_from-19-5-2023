﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using System.Security.Cryptography;

namespace project_30
{
    public class SecureFileProcessor
    {
        public void EncryptAndCompress(string inputFilePath, string outputFilePath)
        {
            using (FileStream inputStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read))
            {
                using (FileStream outputStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.Write))
                {
                    using (Aes aes = Aes.Create())
                    {
                        byte[] Key = aes.Key;
                        byte[] IV = aes.IV;

                        Console.WriteLine($"Key: {Convert.ToBase64String(Key)}");
                        Console.WriteLine($"IV: {Convert.ToBase64String(IV)}");

                        using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(outputStream, encryptor, CryptoStreamMode.Write))
                            {
                                using (GZipStream gzipStream = new GZipStream(cryptoStream, CompressionMode.Compress))
                                {
                                    inputStream.CopyTo(gzipStream);
                                }
                            }
                        }
                    }
                }
            }

            Console.WriteLine($"File compressed and encrypted: {outputFilePath}");
        }

        public void DecryptAndCompress(string inputFilePath, string outputFilePath)
        {
            using (FileStream inputStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read))
            {
                using (FileStream outputStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.Write))
                {
                    using (Aes aes = Aes.Create())
                    {
                        byte[] Key = aes.Key;
                        byte[] IV = aes.IV;

                        Console.WriteLine($"Key: {Convert.ToBase64String(Key)}");
                        Console.WriteLine($"IV: {Convert.ToBase64String(IV)}");

                        using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                        {
                            using (CryptoStream cryptoStream = new CryptoStream(inputStream, decryptor, CryptoStreamMode.Read))
                            {
                                using (GZipStream gzipStream = new GZipStream(cryptoStream, CompressionMode.Decompress))
                                {
                                    gzipStream.CopyTo(outputStream);
                                }
                            }
                        }
                    }
                }
            }

            Console.WriteLine($"File compressed and encrypted: {outputFilePath}");
        }
    }
}
