﻿using System.IO.Compression;
using System.Security.Cryptography;
using System.Runtime.Intrinsics.Arm;
using Aes = System.Security.Cryptography.Aes;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Intrinsics.X86;

namespace project_30
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // ex 1:
            //string inputFilePath = "read.txt";
            //string outputFilePath = "read.txt.gz";
            //using (FileStream inputStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read))
            //{
            //    using (FileStream outputStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.Write))
            //    {
            //        using (GZipStream compressedFile = new GZipStream(outputStream, CompressionMode.Compress))
            //        {
            //            inputStream.CopyTo(outputStream);
            //        }
            //    }
            //}

            // ex 2:
            //string inputFilePath = "read.txt";
            //string outputFilePath = "read_encrypted.dat";
            //using (Aes myAes = Aes.Create())
            //{
            //    byte[] Key = myAes.IV;
            //    byte[] IV = myAes.IV;

            //    Console.WriteLine($"Key: {Convert.ToBase64String(myAes.Key)}");
            //    Console.WriteLine($"IV: {Convert.ToBase64String(myAes.IV)}");

            //    ICryptoTransform encryptor = myAes.CreateEncryptor(myAes.Key, myAes.IV);

            //    using (FileStream inputStream = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read))
            //    {
            //        using (FileStream outputStream = new FileStream(outputFilePath, FileMode.Create, FileAccess.Write))
            //        {
            //            using (CryptoStream cryptoStream = new CryptoStream(outputStream, encryptor, CryptoStreamMode.Write))
            //            {
            //                inputStream.CopyTo(cryptoStream);
            //            }
            //        }
            //    }
            //}

            // ex 3:
            string inputFile1 = "read.txt";
            string secureFile1 = "read.secure";
            SecureFileProcessor secureFileProcessor = new SecureFileProcessor();
            //secureFileProcessor.EncryptAndCompress(inputFile1, secureFile1);
            string inputFile2 = "read.secure";
            string secureFile2 = "read.txt";
            secureFileProcessor.DecryptAndCompress(inputFile2, secureFile2);
        }
    }
}
